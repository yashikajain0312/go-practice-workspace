create table `tbl_3` (`col` int);

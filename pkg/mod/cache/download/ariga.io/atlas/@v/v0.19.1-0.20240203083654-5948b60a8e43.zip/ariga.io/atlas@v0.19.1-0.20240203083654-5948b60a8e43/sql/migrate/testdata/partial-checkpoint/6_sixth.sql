CREATE TABLE `tbl_4` (`col` int);

-- atlas:checkpoint

CREATE TABLE `tbl_1` (`col` int);
CREATE TABLE `tbl_2` (`col` int);

create table `tbl_2` (`col` int);

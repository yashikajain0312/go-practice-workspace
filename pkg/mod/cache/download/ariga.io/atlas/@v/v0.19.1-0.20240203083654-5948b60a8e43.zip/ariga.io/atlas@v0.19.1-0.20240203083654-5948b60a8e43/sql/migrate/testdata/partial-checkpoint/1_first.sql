create table `tbl_1` (`col` int);

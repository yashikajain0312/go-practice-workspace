-- add c3 column
ALTER TABLE t_sub ADD c3 int;
-- add c4 column
ALTER TABLE t_sub ADD c4 int;
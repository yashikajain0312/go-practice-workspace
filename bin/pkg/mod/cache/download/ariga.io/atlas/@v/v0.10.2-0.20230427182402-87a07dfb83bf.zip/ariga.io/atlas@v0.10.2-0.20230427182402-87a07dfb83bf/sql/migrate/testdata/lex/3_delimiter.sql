-- atlas:delimiter \n\n

CREATE INDEX i1 ON t1(c1)

CREATE INDEX i2 ON t2(c2)
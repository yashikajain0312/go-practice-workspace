---
title: About
id: about
slug: /about
---
# About Atlas

<img src="https://atlasgo.io/uploads/gopher.svg" width="200" /> 

Atlas is an open-source project maintained by [Ariga Technologies Ltd](https://ariga.io),
a tech company founded by the maintainers of [Ent](https://entgo.io).

### Reaching Out

If you have a question or want to chat with the Atlas community, 
join our [Discord Server](https://discord.com/invite/QhsmBAWzrC) or 
[open an issue](https://github.com/ariga/atlas/issues) on our [GitHub Repo](https://github.com/ariga/atlas).